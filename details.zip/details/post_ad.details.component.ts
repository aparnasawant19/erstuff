// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute } from '@angular/router';
// import { Post_adService } from './../post_adService';


// @Component({
//     selector: 'app-post_ad-details',
//     templateUrl: './post_ad.details.component.html',
//     styleUrls: ['./post_ad.details.component.css']
// })

// export class Post_adDetailsComponent implements OnInit {
//     adds: any
    
//     constructor(
//         private post_adService: Post_adService,
//         private activatedRoute: ActivatedRoute) {

//             const ad_id = activatedRoute.snapshot.queryParams['ad_id']
//             if(ad_id){
//                 console.log(this.adds)
//                 this.post_adService
//                 .getPost_adDetails(ad_id)
//                 .subscribe(response=>{
//                     if (response['status'] == 'success') {
//                         this.adds = response['data']
//                       }
//                 })
//             }
//             this.vendorService.getVendors().subscribe(response=>{
//                 if(response['status']=='success'){
//                     this.vendors=response['data']
//                     // this.vendor_details=this.vendors[0].vendor_id
//                   this.vendor_details=this.vendors[0].vendor_name
//                 }
//                 else{
//                     console.log(response['error'])
//                 }
//             })
            
//         this.product_id=this.activateRoute.snapshot.params['product_id']
//         this.productService.getProductsById(this.product_id).subscribe(response=>{
//             if(response['status'] = 'success')
//             {
//                 const products = response['data']
//                 console.log(products);
//                 this.product_id = this.product_id
//                 this.vendor_id=products.vendor_id,
//                 this.category_id=products.category_id,
//                 this.product_name=products[0].product_name,
//                 this.description=products[0].description,
//                 this.price=products[0].price,
//                 this.quantity=products[0].quantity
//                 console.log(this.category_id)
                
//             }

//          }

//     ngOnInit() { }
// }
import { ActivatedRoute } from '@angular/router';
import { Post_adService } from './../post_adService';
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-post_ad-details',
    templateUrl: './post_ad.details.component.html',
    styleUrls: ['./post_ad.details.component.css']
})

export class Post_adDetailsComponent implements OnInit {
    adds: any
    
    constructor(
        private post_adService: Post_adService,
        private activatedRoute: ActivatedRoute) {

            const ad_id = activatedRoute.snapshot.queryParams['ad_id']
            if(ad_id){
                console.log(this.adds)
                this.post_adService
                .getPost_adDetails(ad_id)
                .subscribe(response=>{
                    if (response['status'] == 'success') {
                        this.adds = response['data']
                      }
                })
            }
         }

    ngOnInit() { }
}